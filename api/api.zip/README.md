# Red Griffin API Backend
Express API для Red Griffin Creative Ecosystem

## Настройка для Hostinger Node.js Manager
- Framework: Express
- Node.js Version: 18+
- Entry Point: server.ts
- Start Command: npm run dev

## Установка и запуск
1. npm install
2. npm run dev (для разработки)
3. npm start (для продакшена)
